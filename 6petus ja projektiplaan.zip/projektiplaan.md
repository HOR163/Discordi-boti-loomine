# Projektiplaan
## Mida oleks vaja
- Osalejaid 100
- Igas grupis 3-4 osalejat, võiks olla suvaliselt valitud, siis oleks võib olla huvitavam _idk_
- **Arvutid** - ilmselt igale grupile üks, samas siis võib muutuda suta igavaks, kui üks kontrollib ja teised vahivad pealt. Samas kui võtta mitu arvutit ühe grupi peale siis on natuke raske koode kokku panna (ei tahaks gitiga jamama hakata + githubi konto tegemine). Seega hetkel **1 või 2 arvutit meeskonna kohta (kokku 25 - 50 arvutit)**.  
  Või üks osa tegeleb discordi boti paigaldamisega, teine osa tegeleb koodiga. 
- **Tarkvara** - Ilmselt ainult PyCharm (lihtsalt peab vaatama et selle serti / litsentsiga ei oleks probleeme)
- **Abilised** - Iga grupi juurde vast ikka inimest vaja ei ole. Seega äkki iga kahe-kolme grupi peale 1 abiline, oleneb ka sellest millised ülesanded on.

## Töötoa kirjeldus
Uno Bot - discordi bot, millega saab serveris või mingis kanalis unot mängida (ilmselt kanalitega lihtsam? - ei pea uusi servereid hakkama genema (muidugi pole nii raske))
### Ülesanded (hetkel lihtsalt ideed)
- Mingite commandide lisamine (lihtsalt pulli tegemine).
- Koodi kirjutamine ehk teha mäng mängitavaks.
- Funktsionaalsuse lisamine (uued erikaardid).
- Näidete / dokumentatsiooni kirjutamine (oleks igav)
- Kirja pandud juhend, mille järgi lisada funktsionaalsust?
- Niisama väiksemate osadena testimine enne kui paned discordi mängu sisse.
- Discord API muutmine (mitte midagi keerulist, nupu värvi, emoji vms muutmine).
- _veel ideid..._

### Läbi viimine (korraldus)
1. osa: õpetuse järgi boti loomine ja PyCharmi käima saamine jne.  
2. osa: koodi kirjutamine või midagi muud koos juhendajatega / korraldajatega.  
3. osa: vaba valik (äkki teeks mingid juhendid, mille järgi uusi asju lisada ja iga meeskond valib mida teha tahab)  
4. osa: _(lihtsalt mõte, ilmselt ei jõua)_. Turniir. Mängitakse tiim vs tiim erinevate botidega ja kuulutatakse võitja (siis peaks olema ka mingi suhtlus, mis featurid erinevatel tiimidel on). Võib olla võitja(te)le auhind (või siis kõigile, et tublid olid 😁)  


## Millal valmis?
- Enamus mängust probs saab 31. jaanuariks valmis (_maybe_), AI valmimisaeg peaks olema üsna sarnane.  
Eks see millal 100% valmis saab on veel lahtine  
